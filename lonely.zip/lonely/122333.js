let a=10;
let b=20;
console.log(a+b)